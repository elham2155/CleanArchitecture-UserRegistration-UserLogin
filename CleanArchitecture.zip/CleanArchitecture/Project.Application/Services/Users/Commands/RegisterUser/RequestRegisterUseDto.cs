﻿using System.Collections.Generic;

namespace Project.Application.Services.Users.Commands.RegisterUser
{
    public class RequestRegisterUseDto //Execute Parameters
    {
        public string FullName { get; set; }
        public string Email { get; set; }   
        public string Password { get; set; }
        public string RePassword { get; set; }
        public List<RolesRegisterUseDto> Roles { get; set; }
    }
}

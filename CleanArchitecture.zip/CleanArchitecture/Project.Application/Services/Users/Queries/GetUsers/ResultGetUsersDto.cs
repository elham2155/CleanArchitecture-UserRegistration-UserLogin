﻿using System.Collections.Generic;

namespace Project.Application.Services.Users.Queries.GetUsers
{
    public class ResultGetUsersDto //service output
    {
        public List<GetUsersDto> Users { get; set; }
        public int Rows { get; set; }
    }
}

﻿namespace Project.Application.Services.Users.Queries.GetRoles
{
    public class RolesDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }

   
}

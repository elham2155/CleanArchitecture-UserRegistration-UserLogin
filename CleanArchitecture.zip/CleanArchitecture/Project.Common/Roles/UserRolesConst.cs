﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.Common.Roles
{
    public class UserRolesConst
    {
        public const string Admin = "Admin";
        public const string Operator = "Operator";
        public const string Customer = "Customer";
    }
}
